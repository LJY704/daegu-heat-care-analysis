# GitHub 업로드 안내

1. https://github.com 에서 가입하거나 로그인합니다.
2. 오른쪽 위 + → New repository를 선택합니다.
3. Repository name: `daegu-heat-care-analysis` / Public 선택 / Create repository.
4. Add file → Upload files에서 `README.md`, `analyze.py`, `requirements.txt`, `source_2025_districts.csv`, `recomputed_results.csv`, `.gitignore`를 업로드합니다.
5. Commit changes를 누르고 저장소 주소 `https://github.com/본인아이디/daegu-heat-care-analysis`를 복사합니다.
6. PPT의 'GitHub 저장소' 칸에 실제 주소를 넣고 PDF를 다시 내보냅니다.

주의: ZIP 자체가 아니라 내부 파일을 올리세요. 코드는 포트폴리오용 재현 코드이며 공모전 당시 원본 코드는 아닙니다. 지도 생성 코드는 포함되지 않았습니다. 개인정보가 포함된 신청서 등은 업로드하지 마세요.
